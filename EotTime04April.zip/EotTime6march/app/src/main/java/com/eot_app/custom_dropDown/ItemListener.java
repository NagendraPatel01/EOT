package com.eot_app.custom_dropDown;

public interface ItemListener {

    void onItemClick();
}
