package com.eot_app.nav_menu.admin_fw_chat_pkg.sonam_user_user_chat_pkg.usertouser_model;

/**
 * Created by Sonam-11 on 16/4/20.
 */
public class DocUploadModel {
    String cd;

    public DocUploadModel(String cd) {
        this.cd = cd;
    }

    public String getCd() {
        return cd;
    }

    public void setCd(String cd) {
        this.cd = cd;
    }
}
