package com.eot_app.nav_menu.jobs.job_detail.job_equipment.add_job_equip.model_pkg;

public class GetSupplierData {

    private String supId;
    private String supName;

    public String getSupId() {
        return supId;
    }

    public void setSupId(String supId) {
        this.supId = supId;
    }

    public String getSupName() {
        return supName;
    }

    public void setSupName(String supName) {
        this.supName = supName;
    }
}
