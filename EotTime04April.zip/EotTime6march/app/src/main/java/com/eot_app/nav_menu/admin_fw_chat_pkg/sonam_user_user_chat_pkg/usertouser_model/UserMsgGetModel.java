package com.eot_app.nav_menu.admin_fw_chat_pkg.sonam_user_user_chat_pkg.usertouser_model;

/**
 * Created by Sonam-11 on 7/4/20.
 */
public class UserMsgGetModel {
}
