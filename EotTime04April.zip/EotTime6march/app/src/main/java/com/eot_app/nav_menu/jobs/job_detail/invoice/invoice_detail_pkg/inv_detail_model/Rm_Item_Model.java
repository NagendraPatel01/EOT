package com.eot_app.nav_menu.jobs.job_detail.invoice.invoice_detail_pkg.inv_detail_model;

public class Rm_Item_Model {
    String itemId;

    public Rm_Item_Model(String itemId) {
        this.itemId = itemId;
    }

}
