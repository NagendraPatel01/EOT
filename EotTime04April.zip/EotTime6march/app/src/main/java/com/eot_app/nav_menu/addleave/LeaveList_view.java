package com.eot_app.nav_menu.addleave;

import java.util.List;

public interface LeaveList_view {

    void setuserlist(List<LeaveUserModel> list);
}
