package com.eot_app.nav_menu.addleave;

public interface UserLeave_pi {

     void getuserlist();
}
