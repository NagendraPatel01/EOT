package com.eot_app.nav_menu.jobs.add_job.job_weekly_pkg;

/**
 * Created by Sona-11 on 24/3/21.
 */
public interface JOB_weekly_recur_View {
    void setTillDateForRecur(String tillDate);
}
