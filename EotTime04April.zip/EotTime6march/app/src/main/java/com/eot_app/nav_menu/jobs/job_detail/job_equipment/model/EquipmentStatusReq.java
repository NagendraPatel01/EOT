package com.eot_app.nav_menu.jobs.job_detail.job_equipment.model;

/**
 * Created by Sonam-11 on 7/12/20.
 */
public class EquipmentStatusReq {
    String isCondition = "1";

    public EquipmentStatusReq() {
    }
}
