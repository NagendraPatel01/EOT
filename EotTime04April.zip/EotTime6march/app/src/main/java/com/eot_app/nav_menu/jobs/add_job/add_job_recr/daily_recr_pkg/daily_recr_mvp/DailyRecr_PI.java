package com.eot_app.nav_menu.jobs.add_job.add_job_recr.daily_recr_pkg.daily_recr_mvp;

import com.eot_app.nav_menu.jobs.add_job.add_job_recr.daily_recr_pkg.daily_recur_model.DailyMsgReqModel;

/**
 * Created by Sona-11 on 15/3/21.
 */
public interface DailyRecr_PI {

    void getDailyRecurMsg(DailyMsgReqModel dailyMsgReqModel);

}
