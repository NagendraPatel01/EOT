package com.eot_app.home_screens;

/**
 * Created by aplite_pc302 on 8/9/18.
 */

public interface MainActivity_pi {
    void onLogoutServicecall();

    void addCheckInOutIime(String des,String file,String finalFname,String addCheckInOutIime);

}
