package com.eot_app.nav_menu.item;

/**
 * Created by Sonam-11 on 16/10/20.
 */
public class ItemDatum {
    public String ijmmId;
    public String qty;

    public ItemDatum(String ijmmId, String qty) {
        this.ijmmId = ijmmId;
        this.qty = qty;
    }
}
