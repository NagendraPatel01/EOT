package com.eot_app.nav_menu.audit.audit_list;

/**
 * Created by Sonam-11 on 9/12/20.
 */
public interface AuditObserverNotify {
    void onAuditNotifyListner(String key, String msg);
}
