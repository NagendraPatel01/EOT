package com.eot_app.custom_dropDown;

import com.eot_app.utility.settings.setting_db.JobTitle;

import java.util.ArrayList;


public interface ServiceInterface {
    void setSelectedJobServices(ArrayList<JobTitle> selectedJobServices);
}
