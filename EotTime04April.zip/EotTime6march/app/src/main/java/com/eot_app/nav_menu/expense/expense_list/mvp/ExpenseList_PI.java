package com.eot_app.nav_menu.expense.expense_list.mvp;

/**
 * Created by Sonam-11 on 6/5/20.
 */
public interface ExpenseList_PI {
    void getExpenseList(String trim);
}
