package com.eot_app.services;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;


/**
 * Created by Mahendra Dabi on 17/1/20.
 */
public class ScheduleGpsTrack extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        //  HyperLog.i("ForegroundService2", "Start Tracking....");

    }
}
