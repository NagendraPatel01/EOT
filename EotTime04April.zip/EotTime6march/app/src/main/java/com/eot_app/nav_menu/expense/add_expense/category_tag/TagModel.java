package com.eot_app.nav_menu.expense.add_expense.category_tag;

/**
 * Created by Sonam-11 on 8/5/20.
 */
public class TagModel {
    private String etId;
    private String name;

    public String getEtId() {
        return etId;
    }

    public void setEtId(String etId) {
        this.etId = etId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
