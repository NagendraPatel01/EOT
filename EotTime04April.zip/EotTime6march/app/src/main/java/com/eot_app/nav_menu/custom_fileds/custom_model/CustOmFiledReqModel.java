package com.eot_app.nav_menu.custom_fileds.custom_model;

/**
 * Created by Sonam-11 on 16/9/20.
 */
public class CustOmFiledReqModel {
    final String frmId;
    final String type;

    public CustOmFiledReqModel(String type) {
        this.frmId = "";
        this.type = type;
    }
}
