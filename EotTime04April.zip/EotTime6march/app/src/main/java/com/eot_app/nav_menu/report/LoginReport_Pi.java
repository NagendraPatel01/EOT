package com.eot_app.nav_menu.report;

public interface LoginReport_Pi {

    void getLoginReport(GetReport_Req getReport_req);

    //Response{protocol=http/1.1, code=404, message=Not Found, url=https://as1.eyeontask.com/en/eotServices/eotServices/UserController/generateCheckInOutPDF}
}
