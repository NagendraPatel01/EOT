package com.eot_app.nav_menu.client_chat_pkg.client_chat_model;

/**
 * Created by Sonam-11 on 2020-01-29.
 */
public class ClientChatFireBaseModel {
    private int cltunread;

    public int getCltunread() {
        return cltunread;
    }

    public void setCltunread(int cltunread) {
        this.cltunread = cltunread;
    }
}
