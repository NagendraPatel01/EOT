package com.eot_app.nav_menu.client_chat_pkg.client_chat_mvp;

import android.graphics.drawable.Drawable;
import android.view.View;

/**
 * Created by Sonam-11 on 2020-01-02.
 */
public interface ClientChat_View {
    void openImage(View thumbView, Drawable bmp, String img_url);
}
