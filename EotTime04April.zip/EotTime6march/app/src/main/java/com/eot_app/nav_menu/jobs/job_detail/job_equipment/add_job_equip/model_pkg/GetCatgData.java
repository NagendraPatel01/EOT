package com.eot_app.nav_menu.jobs.job_detail.job_equipment.add_job_equip.model_pkg;

/**
 * Created by Sonam-11 on 30/9/20.
 */
public class GetCatgData {
    private String ecId;
    private String equ_cate;

    public String getEcId() {
        return ecId;
    }

    public void setEcId(String ecId) {
        this.ecId = ecId;
    }

    public String getEquCate() {
        return equ_cate;
    }

    public void setEquCate(String equCate) {
        this.equ_cate = equCate;
    }
}
