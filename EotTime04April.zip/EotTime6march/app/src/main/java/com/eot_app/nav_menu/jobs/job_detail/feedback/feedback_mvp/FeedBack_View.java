package com.eot_app.nav_menu.jobs.job_detail.feedback.feedback_mvp;

/**
 * Created by ubuntu on 16/10/18.
 */

public interface FeedBack_View {
    void onSessionExpire(String msg);

    void onfeedbackSendSuccessfully();
}
