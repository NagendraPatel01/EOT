package com.eot_app.nav_menu.jobs.add_job.add_job_recr.dateTime_pkg;

public interface DateTimeCallBack {
    void getDateTimeFromPicker(String currentDateString);
}
