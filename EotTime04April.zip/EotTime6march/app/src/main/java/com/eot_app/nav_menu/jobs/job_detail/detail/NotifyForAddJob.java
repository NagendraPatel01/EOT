package com.eot_app.nav_menu.jobs.job_detail.detail;

public interface NotifyForAddJob {
    void updateJobId(String tempId,String jobId);
}
