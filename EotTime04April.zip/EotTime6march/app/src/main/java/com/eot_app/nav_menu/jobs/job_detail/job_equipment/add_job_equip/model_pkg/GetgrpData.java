package com.eot_app.nav_menu.jobs.job_detail.job_equipment.add_job_equip.model_pkg;

/**
 * Created by Sonam-11 on 30/9/20.
 */
public class GetgrpData {

    private String egId;
    private String equ_group;

    public String getEgId() {
        return egId;
    }

    public void setEgId(String egId) {
        this.egId = egId;
    }

    public String getEquGroup() {
        return equ_group;
    }

    public void setEquGroup(String equGroup) {
        this.equ_group = equGroup;
    }
}

