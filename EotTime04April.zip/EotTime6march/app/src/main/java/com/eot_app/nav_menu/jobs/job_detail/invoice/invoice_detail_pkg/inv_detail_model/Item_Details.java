package com.eot_app.nav_menu.jobs.job_detail.invoice.invoice_detail_pkg.inv_detail_model;

public class Item_Details {
    private String cmpnm;
    private String adr;
    private String city;
    private String country;
    private String cmpemail;


    public String getCmpnm() {
        return cmpnm;
    }

    public void setCmpnm(String cmpnm) {
        this.cmpnm = cmpnm;
    }

    public String getAdr() {
        return adr;
    }

    public void setAdr(String adr) {
        this.adr = adr;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCmpemail() {
        return cmpemail;
    }

    public void setCmpemail(String cmpemail) {
        this.cmpemail = cmpemail;
    }
}


