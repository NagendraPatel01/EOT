package com.eot_app.nav_menu.admin_fw_chat_pkg.sonam_user_user_chat_pkg.usertouser_model;

/**
 * Created by Sona-11 on 31/12/21.
 */
public class GrpUsrlistStatus {
   private String usrIm;
    private  String status;
    private  String nm;

    public String getUsrIm() {
        return usrIm;
    }

    public void setUsrIm(String usrIm) {
        this.usrIm = usrIm;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNm() {
        return nm;
    }

    public void setNm(String nm) {
        this.nm = nm;
    }
}
