package com.eot_app.nav_menu.jobs.add_job.job_weekly_pkg;

import com.eot_app.nav_menu.jobs.add_job.add_job_recr.daily_recr_pkg.daily_recur_model.DailyMsgReqModel;

/**
 * Created by Sona-11 on 24/3/21.
 */
public interface JOB_weekly_recur_PI {
    void getTillDateForRecur(String startDate);
}
